"use client"
import { Form } from "@/app/Week6/lab6/form"

const home = () => {
    return (
        <>
            <div className="">
                <Form />
            </div>

        </>
    )
}

export default home